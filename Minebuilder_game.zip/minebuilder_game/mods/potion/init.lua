minetest.register_node("potion:red", {
	description = "Potion Bottle",
	drawtype = "plantlike",
	tiles = {"potion.png"},
	inventory_image = "potion.png",
	wield_image = "potion.png",
	paramtype = "light",
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.25, -0.5, -0.25, 0.25, 0.4, 0.25}
	},
	groups = {potion=1,dig_immediate=3,attached_node=1},
	sounds = default.node_sound_glass_defaults(),
})

minetest.register_craft( {
	output = "potion:red 5",
	recipe = {
		{ "default:glass", "", "default:glass" },
		{ "default:glass", "", "default:glass" },
		{ "", "default:apple", "" }
	}
})
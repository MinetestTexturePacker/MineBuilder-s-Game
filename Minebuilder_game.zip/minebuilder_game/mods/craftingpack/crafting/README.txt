Minetest mod "Crafting"
=======================
Version: 2.0.1

License of source code and Textures: WTFPL
------------------------------------
copyright (c) 2013-2014 by BlockMen

This program is free software. It comes without any warranty, to
the extent permitted by applicable law. You can redistribute it
and/or modify it under the terms of the Do What The Fuck You Want
To Public License, Version 2, as published by Sam Hocevar. See
http://sam.zoy.org/wtfpl/COPYING for more details.


--USING the mod--
=================

This mod changes the players inventory (survival and creative) with more slots (9*4 instead of 8*4)
Like known from Minecraft you have a 2x2 crafting grid at inventory now. Furthermore a categorized creative
inventory and a support for stu's 3d armor mod (To use the armor and a preview of player).

Left items in the crafting slots are dropped infront of you.


Workbench
_________

With following recipe you craft a workbench (aka crafting table):

wood wood
wood wood

The workbench has a 3x3 crafting grid, that allows to use all recipes.